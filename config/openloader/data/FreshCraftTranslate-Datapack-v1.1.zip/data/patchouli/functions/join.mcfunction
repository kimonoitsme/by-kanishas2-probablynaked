# Эта функция будет выполнена при входе нового игрока
function patchouli:give_book