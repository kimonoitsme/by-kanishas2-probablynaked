# Создание scoreboard для отслеживания получения книги
scoreboard objectives add hasBook dummy